create
    definer = root@localhost procedure pro_total_score(IN student_id varchar(12), IN m_id varchar(12),
                                                       IN a_id varchar(12), IN semester varchar(15), IN grade int,
                                                       IN major varchar(50), IN stu_name varchar(20), IN pageIndex int,
                                                       IN pageSize int, OUT pageCount int, OUT totalRecordCount int)
BEGIN 
		SET NAMES 'utf8';
		set @name_sql = '';
		set @student_id = '';
		set @menter_id = '';
		set @admin_id ='';
		set @semester ='';
		set @grade = '';
		set @stu_name = '';
		set @major = '';
		set @concat_sql = '';
		set @recordCount=0;
		set @tmp=1;

DROP TEMPORARY TABLE IF EXISTS TemprResultData;
CREATE TEMPORARY TABLE IF NOT EXISTS TempResultData(

SELECT 
student.stu_Id AS stu_Id, 
student.stu_Name AS stu_Name,
gpa.ungetcredit AS ungetcredit,
gpa.GPA_score*20 AS total_GPA,
IFNULL(B.total_moral,0) AS total_moral,
IFNULL(B.total_competition,0) AS total_competition,
IFNULL(B.total_innovate,0) AS total_innovate,
IFNULL(C.total_publicwelfare,0) AS total_publicwelfare,
IFNULL(D.total_elsepoint,0) AS total_elsepoint,
IFNULL(E.total_violate,0) AS total_violate,
gpa.semester AS semester
FROM gpa LEFT JOIN 
 student ON student.stu_Id = gpa.stu_Id
 
/*计算德育总分、竞赛加分、创新总分*/
LEFT JOIN 
(SELECT A.stu_Id AS stu_Id,
A.stu_Name AS stu_Name,
sum(IF (`tem_Name` = '德育加分',score,0))AS total_moral,
sum(IF (`tem_Name` = '竞赛加分',score,0))AS total_competition,
sum(IF (`tem_Name` = '创新加分',score,0))AS total_innovate,
A.semester AS semester 
FROM 
(SELECT student.stu_Id,student.stu_Name,template.tem_Name ,application.semester,sum(awardlever.awl_Score)AS score
FROM student LEFT JOIN application ON student.stu_Id = application.stu_Id
		     LEFT JOIN awardlever ON awardlever.awl_Id = application.awl_Id
		    LEFT JOIN project ON project.pro_Id = awardlever.pro_Id
		  LEFT JOIN template ON template.tem_Id = project.tem_Id
		WHERE application.state = '通过' 
		GROUP BY template.tem_Name,student.stu_Id,application.semester)AS A GROUP BY A.stu_Id,A.semester) B ON B.stu_Id = student.stu_Id AND B.semester = gpa.semester

/*公益总分*/
LEFT JOIN 
(SELECT student.stu_Id AS stu_Id,sum(publicwelfare.PW_score)AS total_publicwelfare,publicwelfare.semester AS semester
FROM student,publicwelfare WHERE publicwelfare.stu_Id = student.stu_Id 
GROUP BY student.stu_Id,publicwelfare.semester
)C ON student.stu_Id = C.stu_Id AND C.semester = gpa.semester 

/*其他加分总分*/
LEFT JOIN 
(SELECT student.stu_Id AS stu_Id,sum(E_score)AS total_elsepoint,`elsepoint`.semester AS semester
FROM student,`elsepoint` WHERE `elsepoint`.stu_Id = student.stu_Id 
GROUP BY student.stu_Id,`elsepoint`.semester
)D ON student.stu_Id = D.stu_Id AND D.semester = gpa.semester

/*违纪扣分*/
LEFT JOIN	
(SELECT student.stu_Id AS stu_Id,sum(violation.vio_Score)AS total_violate,violation.semester AS semester
FROM student,violation WHERE violation.stu_Id = student.stu_Id AND cancel_Time ='0001-01-01'
GROUP BY student.stu_Id,violation.semester
)E ON student.stu_Id = E.stu_Id AND E.semester = gpa.semester
);

/*根据统计结果限制德育加分总分小于12，竞赛小于6、创新小于9*/
UPDATE TempResultData SET total_moral =12 WHERE total_moral>12;
UPDATE TempResultData SET total_competition =6 WHERE total_competition>6;
UPDATE TempResultData SET total_innovate =9 WHERE total_innovate>9;




/*学生端*/
if
student_id is not null and student_id <> '' 
and EXISTS(SELECT * FROM student WHERE stu_Id = student_id)
then 	
 select TR.stu_Id AS stu_Id,
				TR.stu_Name AS stu_Name, 
				TR.ungetcredit AS ungetcredit,
				total_GPA AS total_GPA, 
				total_moral AS total_moral, 
				total_competition AS total_competition, 
				total_innovate AS total_innovate, 
				total_publicwelfare AS total_publicwelfare,
				total_elsepoint AS total_elsepoint, 
				total_violate AS total_violate, 
				TR.semester AS semester,
				(total_GPA + total_moral+ total_competition  + total_innovate + total_publicwelfare + total_elsepoint+ 					total_violate)AS total_score, 
				rank()over(PARTITION BY student.major,student.grade,semester ORDER BY (total_GPA + total_moral+ 				total_competition  + total_innovate + total_publicwelfare + total_elsepoint+ total_violate) DESC)AS ranking		 
				FROM TempResultData TR LEFT JOIN student ON TR.stu_Id = student.stu_Id where student.stu_Id = student_id;
end if;





/*辅导员端*/
if m_id is not null and m_id <> '' 
and EXISTS(SELECT * FROM menter WHERE menter_Id = m_id)
then
		
		if student_id is not null and student_id <> ''
		then 
			set @student_id = CONCAT(' and student.stu_Id = ',student_id);
		end if;
		
		if semester is not null and semester <> ''
		then 
			set @semester = CONCAT(' and TR.semester = ',"'",semester,"'");
		end if;
		
		if grade is not null and grade <> ''
		then 
			set @grade = CONCAT(' and student.grade = ',"'",grade,"'");
		end if;
		
		
		if major is not null and major <> ''
		then 
			set @major = CONCAT(' and student.major = ',"'",major,"'");
		end if;
		
		
		if stu_name is not null and stu_name <> ''
		then 
			set @name_sql = CONCAT(' and student.stu_name like',"'%",stu_name,"%'");
		end if;

/*计算总记录数*/
			set @concat_sql = concat('select count(*) into @recordCount
				FROM TempResultData TR LEFT JOIN student ON TR.stu_Id = student.stu_Id where 1=1',@student_id,@semester,@grade,@major,@name_sql,';');
				prepare stmt from @concat_sql; 
				execute stmt; 
				deallocate prepare stmt; 
				set totalRecordCount = @recordCount; 

/*计算返回的总页数*/	
			set @tmp=@recordCount mod pageSize; 
			if @tmp=0 then
				set pageCount=@recordCount div pageSize;
			else
				set pageCount=@recordCount div pageSize + 1;
			end if;

set @concat_sql = concat('select
				TR.stu_Id AS stu_Id, 
				TR.stu_Name AS stu_Name, 
				TR.ungetcredit AS ungetcredit,
				total_GPA AS total_GPA, 
				total_moral AS total_moral, 
				total_competition AS total_competition,
				total_innovate AS total_innovate, 
				total_publicwelfare AS total_publicwelfare,
				total_elsepoint AS total_elsepoint, 
				total_violate AS total_violate, 
				TR.semester AS semester,
				(total_GPA + total_moral+ total_competition  + total_innovate + total_publicwelfare + total_elsepoint+ 					total_violate)AS total_score , 
				rank()over(PARTITION BY student.major,student.grade,semester ORDER BY (total_GPA + total_moral+ 				total_competition  + total_innovate + total_publicwelfare + total_elsepoint+ total_violate) DESC)AS ranking		 
				FROM TempResultData TR LEFT JOIN student ON TR.stu_Id = student.stu_Id where 1=1',@student_id,@semester,@grade,@major,@name_sql,' limit ',(pageIndex-1)*pageSize,',',pageSize,';');
end if;






/*管理员端*/
if a_id is not null and a_id <> '' 
then
		
		if student_id is not null and student_id <> ''
		then 
			set @student_id = CONCAT(' and student.stu_Id = ',student_id);
		end if;
		
		if semester is not null and semester <> ''
		then 
			set @semester = CONCAT(' and TR.semester = ',"'",semester,"'");
		end if;
		
		if grade is not null and grade <> ''
		then 
			set @grade = CONCAT(' and student.grade = ',"'",grade,"'");
		end if;
		
		
		if major is not null and major <> ''
		then 
			set @major = CONCAT(' and student.major = ',"'",major,"'");
		end if;
		
		
		if stu_name is not null and stu_name <> ''
		then 
			set @name_sql = CONCAT(' and student.stu_name like',"'%",stu_name,"%'");
		end if;


/*计算总记录数*/
set @concat_sql = concat('select count(*) into @recordCount
				FROM TempResultData TR LEFT JOIN student ON TR.stu_Id = student.stu_Id where 1=1',@student_id,@semester,@grade,@major,@name_sql,';');
				prepare stmt from @concat_sql; 
				execute stmt; 
				deallocate prepare stmt; 
				set totalRecordCount = @recordCount; /*总记录数*/

	/*计算返回的总页数*/	
			set @tmp=@recordCount mod pageSize; /*取余数*/
			if @tmp=0 then
				set pageCount=@recordCount div pageSize;
			else
				set pageCount=@recordCount div pageSize + 1;
			end if;

set @concat_sql = concat('select
				TR.stu_Id AS stu_Id, 
				TR.stu_Name AS stu_Name, 
				TR.ungetcredit AS ungetcredit,
				total_GPA AS total_GPA, 
				total_moral AS total_moral, 
				total_competition AS total_competition,
				total_innovate AS total_innovate, 
				total_publicwelfare AS total_publicwelfare,
				total_elsepoint AS total_elsepoint, 
				total_violate AS total_violate, 
				TR.semester AS semester,
				(total_GPA + total_moral+ total_competition  + total_innovate + total_publicwelfare + total_elsepoint+ 					total_violate)AS total_score , 
				rank()over(PARTITION BY student.major,student.grade,semester ORDER BY (total_GPA + total_moral+ 				total_competition  + total_innovate + total_publicwelfare + total_elsepoint+ total_violate) DESC)AS ranking		 
				FROM TempResultData TR LEFT JOIN student ON TR.stu_Id = student.stu_Id where 1=1',@student_id,@semester,@grade,@major,@name_sql,' limit ',(pageIndex-1)*pageSize,',',pageSize,';');
end if;


prepare stmt from @concat_sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
/*truncate table TempResultData;*/
END;

