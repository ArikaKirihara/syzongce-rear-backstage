create definer = root@localhost view award_view as
select `test`.`template`.`tem_Id`       AS `tem_Id`,
       `test`.`template`.`tem_Name`     AS `tem_Name`,
       `test`.`project`.`pro_Id`        AS `pro_Id`,
       `test`.`project`.`pro_Name`      AS `pro_Name`,
       `test`.`awardlever`.`awl_Id`     AS `awl_Id`,
       `test`.`awardlever`.`awl_Detail` AS `awl_Detail`,
       `test`.`awardlever`.`awl_Score`  AS `awl_Score`
from ((`test`.`awardlever` join `test`.`project`)
         join `test`.`template`)
where ((`test`.`template`.`tem_Id` = `test`.`project`.`tem_Id`) and
       (`test`.`project`.`admin_Id` = `test`.`template`.`admin_Id`));

