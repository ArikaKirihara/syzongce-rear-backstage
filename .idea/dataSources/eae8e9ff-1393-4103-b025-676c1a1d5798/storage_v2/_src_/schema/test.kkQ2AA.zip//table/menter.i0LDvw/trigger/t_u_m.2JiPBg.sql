create definer = root@localhost trigger t_u_m
    after update
    on menter
    for each row
BEGIN
							UPDATE student SET menter_Id = new.menter_Id WHERE menter_Id = old.menter_Id;
						END;

