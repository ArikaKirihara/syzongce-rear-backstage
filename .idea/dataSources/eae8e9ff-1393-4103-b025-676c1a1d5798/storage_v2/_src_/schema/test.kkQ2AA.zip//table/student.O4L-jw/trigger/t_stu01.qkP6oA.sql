create definer = root@localhost trigger t_stu01
    after delete
    on student
    for each row
begin 
						DELETE FROM aplication WHERE stu_Id=old.stu_Id;			
					end;

