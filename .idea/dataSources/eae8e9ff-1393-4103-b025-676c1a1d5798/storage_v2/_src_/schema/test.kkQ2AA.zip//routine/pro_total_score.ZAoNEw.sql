create
    definer = root@localhost procedure pro_total_score()
BEGIN
/*DROP TEMPORARY TABLE IF EXISTS TemprResultData;*/
CREATE TEMPORARY TABLE IF NOT EXISTS TempResultData(

SELECT 
student.stu_Id AS stu_Id, 
student.stu_Name AS stu_Name,
gpa.ungetcredit AS ungetcredit,
gpa.GPA_score*20 AS total_GPA,
IFNULL(B.total_moral,0) AS total_moral,
IFNULL(B.total_competition,0) AS total_competition,
IFNULL(B.total_innovate,0) AS total_innovate,
IFNULL(C.total_publicwelfare,0) AS total_publicwelfare,
IFNULL(D.total_elsepoint,0) AS total_elsepoint,
IFNULL(E.total_violate,0) AS total_violate,
gpa.semester AS semester
FROM gpa LEFT JOIN 
 student ON student.stu_Id = gpa.stu_Id
 
/*计算德育总分、竞赛加分、创新总分*/
LEFT JOIN 
(SELECT A.stu_Id AS stu_Id,
A.stu_Name AS stu_Name,
sum(IF (`tem_Name` = '德育加分',score,0))AS total_moral,
sum(IF (`tem_Name` = '竞赛加分',score,0))AS total_competition,
sum(IF (`tem_Name` = '创新加分',score,0))AS total_innovate,
A.semester AS semester 
FROM 
(SELECT student.stu_Id,student.stu_Name,template.tem_Name ,application.semester,sum(awardlever.awl_Score)AS score
FROM student LEFT JOIN application ON student.stu_Id = application.stu_Id
		     LEFT JOIN awardlever ON awardlever.awl_Id = application.awl_Id
		    LEFT JOIN project ON project.pro_Id = awardlever.pro_Id
		  LEFT JOIN template ON template.tem_Id = project.tem_Id
		WHERE application.state = '通过' 
		GROUP BY template.tem_Name,student.stu_Id,application.semester)AS A GROUP BY A.stu_Id,A.semester) B ON B.stu_Id = student.stu_Id AND B.semester = gpa.semester

/*公益总分*/
JOIN 
(SELECT student.stu_Id AS stu_Id,sum(publicwelfare.PW_score)AS total_publicwelfare,publicwelfare.semester AS semester
FROM student,publicwelfare WHERE publicwelfare.stu_Id = student.stu_Id 
GROUP BY student.stu_Id,publicwelfare.semester
)C ON student.stu_Id = C.stu_Id AND C.semester = gpa.semester 

/*其他加分总分*/
JOIN 
(SELECT student.stu_Id AS stu_Id,sum(E_score)AS total_elsepoint,`elsepoint`.semester AS semester
FROM student,`elsepoint` WHERE `elsepoint`.stu_Id = student.stu_Id 
GROUP BY student.stu_Id,`elsepoint`.semester
)D ON student.stu_Id = D.stu_Id AND D.semester = gpa.semester

/*违纪扣分*/
JOIN	
(SELECT student.stu_Id AS stu_Id,sum(violation.vio_Score)AS total_violate,violation.semester AS semester
FROM student,violation WHERE violation.stu_Id = student.stu_Id AND cancel_Time ='0001-01-01'
GROUP BY student.stu_Id,violation.semester
)E ON student.stu_Id = E.stu_Id AND E.semester = gpa.semester
);

/*根据统计结果限制德育加分总分小于12，竞赛小于6、创新小于9*/
UPDATE TempResultData SET total_moral =12 WHERE total_moral>12;
UPDATE TempResultData SET total_competition =6 WHERE total_moral>6;
UPDATE TempResultData SET total_innovate =9 WHERE total_moral>9;


SELECT  TR.stu_Id, /* AS'学号'*/
				TR.stu_Name, /*AS'姓名'*/
				TR.ungetcredit, /* AS'未得学分'*/
				total_GPA, /* AS '绩点'*/
				total_moral, /* AS '德育总分'*/
				total_competition, /* AS '竞赛总分'*/
				total_innovate, /* AS '创新总分'*/
				total_publicwelfare, /* AS '公益加分'*/
				total_elsepoint,  /* AS '其他加分'*/ 
				total_violate,  /* AS '违纪扣分'*/
				semester, /* AS '学期'*/
				(total_GPA + total_moral+ total_competition  + total_innovate + total_publicwelfare + total_elsepoint+
                total_violate)AS total_score , 
				rank()over(PARTITION BY student.major,student.grade,semester
                ORDER BY (total_GPA + total_moral+total_competition  + total_innovate + total_publicwelfare + total_elsepoint+ total_violate) DESC)AS ranking
				FROM TempResultData TR LEFT JOIN student ON TR.stu_Id = student.stu_Id;
			
truncate table TempResultData;
END;

