create definer = root@localhost trigger t_stu02
    after delete
    on student
    for each row
begin
					DELETE FROM violation WHERE stu_Id=old.stu_Id;		
					end;

